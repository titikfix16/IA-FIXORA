# IA FIXORA
Aplikasi offline pencatatan uang masuk dan keluar untuk usaha servis smartphone.

## Fitur awal
- Penyimpanan lokal SQLite (offline)
- Catat transaksi masuk dan keluar
- Kategori, metode pembayaran, dan catatan
- Ringkasan saldo, total masuk, total keluar
- Riwayat transaksi

## Build APK dari GitHub
1. Unggah seluruh isi folder proyek ini ke repository `IA-FIXORA` pada branch `main`.
2. Buka tab **Actions** di repository.
3. Pilih workflow **Build APK IA FIXORA**.
4. Tekan **Run workflow** jika belum berjalan otomatis.
5. Setelah selesai, buka hasil workflow dan unduh artifact `IA-FIXORA-debug-apk`.
6. Ekstrak ZIP artifact untuk mendapatkan `app-debug.apk`.

Build pertama adalah APK debug untuk uji coba, bukan release publik.
