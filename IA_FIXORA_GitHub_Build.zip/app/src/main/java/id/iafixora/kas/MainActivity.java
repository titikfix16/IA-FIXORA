package id.iafixora.kas;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    SQLiteDatabase db;
    LinearLayout root, list;
    EditText amount, note;
    Spinner type, category, method;
    TextView balance, income, expense;
    int orange = Color.rgb(238,112,45);
    String[] categories = {"Servis","Sparepart","Aksesoris","Operasional","Lain-lain"};
    String[] methods = {"Tunai","Transfer","QRIS"};
    String money(long n) { return NumberFormat.getCurrencyInstance(new Locale("id","ID")).format(n); }

    public void onCreate(Bundle b) {
        super.onCreate(b);
        db = openOrCreateDatabase("iafixora.db", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS transaksi(id INTEGER PRIMARY KEY AUTOINCREMENT, jenis TEXT, kategori TEXT, jumlah INTEGER, metode TEXT, catatan TEXT, waktu TEXT DEFAULT CURRENT_TIMESTAMP)");
        show();
    }
    TextView label(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY); t.setPadding(0,8,0,8); return t;
    }
    void show() {
        root = new LinearLayout(this); root.setOrientation(1); root.setPadding(22,20,22,20); root.setBackgroundColor(Color.rgb(248,248,248));
        ScrollView sc = new ScrollView(this); sc.addView(root); setContentView(sc);
        TextView title = label("IA FIXORA", 28); title.setTextColor(orange); title.setTypeface(null,1); root.addView(title);
        root.addView(label("Pencatatan Uang Masuk & Keluar",16));
        long masuk=sum("Masuk"), keluar=sum("Keluar");
        balance=label("SALDO SEKARANG\\n"+money(masuk-keluar),22); balance.setTextColor(Color.BLACK); balance.setTypeface(null,1); root.addView(balance);
        root.addView(label("Uang masuk: "+money(masuk)+"     Uang keluar: "+money(keluar),14));
        root.addView(label("Tambah transaksi",20));
        type = spinner(new String[]{"Masuk","Keluar"}); root.addView(type);
        category = spinner(categories); root.addView(category);
        amount = new EditText(this); amount.setHint("Jumlah (contoh: 50000)"); amount.setInputType(2); root.addView(amount);
        method = spinner(methods); root.addView(method);
        note = new EditText(this); note.setHint("Catatan (opsional)"); root.addView(note);
        Button save = new Button(this); save.setText("SIMPAN TRANSAKSI"); save.setBackgroundTintList(android.content.res.ColorStateList.valueOf(orange)); save.setTextColor(Color.WHITE); root.addView(save);
        save.setOnClickListener(v -> save());
        root.addView(label("Riwayat transaksi",20));
        list = new LinearLayout(this); list.setOrientation(1); root.addView(list);
        Cursor c=db.rawQuery("SELECT id,jenis,kategori,jumlah,metode,catatan,waktu FROM transaksi ORDER BY id DESC LIMIT 100",null);
        while(c.moveToNext()) {
            String s=c.getString(1)+" • "+c.getString(2)+" • "+money(c.getLong(3))+"\\n"+c.getString(4)+" | "+c.getString(5)+"\\n"+c.getString(6);
            TextView row=label(s,14); row.setBackgroundColor(Color.WHITE); row.setPadding(12,12,12,12); list.addView(row);
            View line=new View(this); line.setBackgroundColor(0xFFE0E0E0); line.setLayoutParams(new LinearLayout.LayoutParams(-1,1)); list.addView(line);
        }
        c.close();
    }
    Spinner spinner(String[] values) { Spinner s=new Spinner(this); ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values); s.setAdapter(a); return s; }
    long sum(String kind) { Cursor c=db.rawQuery("SELECT COALESCE(SUM(jumlah),0) FROM transaksi WHERE jenis=?",new String[]{kind}); c.moveToFirst(); long n=c.getLong(0); c.close(); return n; }
    void save() {
        String a=amount.getText().toString().trim();
        if(a.isEmpty() || Long.parseLong(a)<=0) { Toast.makeText(this,"Masukkan jumlah yang benar",Toast.LENGTH_SHORT).show(); return; }
        ContentValues v=new ContentValues(); v.put("jenis",type.getSelectedItem().toString()); v.put("kategori",category.getSelectedItem().toString()); v.put("jumlah",Long.parseLong(a)); v.put("metode",method.getSelectedItem().toString()); v.put("catatan",note.getText().toString().trim());
        db.insert("transaksi",null,v); Toast.makeText(this,"Transaksi tersimpan",Toast.LENGTH_SHORT).show(); show();
    }
}